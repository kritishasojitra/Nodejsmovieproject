const mongoose=require('mongoose')


const schema=mongoose.Schema({
    name:{
        type: String,
        // required: true
    },
    addr:{
        type: String,
        // required: true
    },
    city:{
        type: String,
        // required: true
    },
    moviename:{
        type:String,
        // required: true
    },
    lan:{
        type:String,
        // required: true
    },
    gen:{
        type:String,
        // required: true
    },
    for:{
        type:String,
        // required: true
    },
    image:{
        type:String,
        // required: true
    }
})

const movietables=mongoose.model('movietables',schema);

module.exports=movietables;