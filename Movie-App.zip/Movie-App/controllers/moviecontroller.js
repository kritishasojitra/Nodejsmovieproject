const movietables= require("../model/schema");

const Home=(req,res)=>{
    res.render('home');
}

const insert=(req,res)=>{

    console.log(req.body);
    console.log(req.file);


    movietables.create({
        city:req.body.city,
        moviename:req.body.moviename,
        lan:req.body.lan,
        gen:req.body.gen,
        for:req.body.for,
        image:req.file.path
    }).then(()=>{
        console.log("data insert....");
        return res.redirect('/table')
    })
}

const Table=(req,res)=>{


    movietables.find({}).then((alldata)=>{
        res.render('table',{
            data: alldata
        })
    })
}

const Delete=(req,res)=>{
    let id=req.query.id;

    movietables.findByIdAndDelete(id)
    .then(()=>{
        console.log("Data delete....");
        return res.redirect('/table')
    })
}


const Edit=(req,res)=>{

    let id=req.query.id;

    movietables.findById(id)
    .then((alldata)=>{
        res.render('edit',{
            edit:alldata
        })
    })
   
}

const update=(req,res)=>{
    let id=req.body.id;

    console.log(req.file)

    if(req.file)
    {
        var data={
            city:req.body.city,
            moviename:req.body.moviename,
            lan:req.body.lan,
            gen:req.body.gen,
            for:req.body.for,
            image:req.file.path  
        }
    }
    else{

        var data={
        city:req.body.city,
        moviename:req.body.moviename,
        lan:req.body.lan,
        gen:req.body.gen,
        for:req.body.for
        }
    }

    movietables.findByIdAndUpdate(id,data)
    .then((updatedData) => {
        console.log("data update....");
        return res.redirect('/table')
    })
}



module.exports={
    Home,insert,
    Table,
    Delete ,
    Edit,
    update  
}